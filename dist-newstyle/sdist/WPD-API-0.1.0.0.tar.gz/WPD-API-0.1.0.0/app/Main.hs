{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE BlockArguments #-}
{-# LANGUAGE DeriveGeneric #-}

import Web.Scotty as S
import Network.HTTP.Client.MultipartFormData (formDataBody, partFileSource, partLBS)
import Network.HTTP.Client as C (RequestBody, Response(..), httpLbs, parseRequest, newManager)
import Network.HTTP.Client.TLS (tlsManagerSettings)
import Network.HTTP.Simple
import Data.Aeson (encode, decode')
import Control.Monad.IO.Class (liftIO)
import qualified Data.ByteString.Lazy.Char8 as L8
import GHC.Generics (Generic)
import Data.Text.Lazy (Text, pack)
import Data.Aeson.Types
import Data.Text.Lazy.Encoding (decodeUtf8)
import qualified Data.ByteString.Lazy as BL
import System.Environment (getEnv)
import System.Directory (doesFileExist)

apiKey :: String
apiKey = "AIzaSyC0xCqsrg7x4HyRuRJPLaIZYvHqHKxsgm0"

makeBody :: String -> String
makeBody [] = "{\"contents\": [{\"parts\":[{\"text\": \"\"}]}]}"
makeBody a  = "{\"contents\": [{\"parts\":[{\"text\": \"" ++ a ++ "\"}]}]}"

-- Function to upload the image and get the file URI
uploadImage :: FilePath -> IO Text
uploadImage imagePath = do
  -- Create a request to upload the image
  request <- parseRequest $ "https://generativelanguage.googleapis.com/upload/v1beta/files?uploadType=media&key=" ++ apiKey
  fileContent <- BL.readFile imagePath
  let request' = setRequestMethod "POST"
               $ setRequestHeader "Content-Type" ["image/jpeg"]
               $ setRequestBodyLBS fileContent request

  -- Send the request and decode the JSON response
  response <- C.httpLbs request'
  let body = responseBody response
  case decode' body of
    Just obj -> case parseMaybe (withObject "root" (\o -> o .: "file" >>= (.: "uri"))) obj of
      Just uri -> return $ pack uri
      Nothing -> error "Failed to extract file URI from response"
    Nothing -> error "Failed to decode JSON response"

main :: IO ()
main = S.scotty 3000 $ do


  S.get "/" $ do
    uri <- liftIO $ uploadImage "example.png"
    S.text uri

  S.post "/gemini" $ do
    let url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyC0xCqsrg7x4HyRuRJPLaIZYvHqHKxsgm0" 
    initialRequest <- liftIO $ parseRequest url

    let requestBody = makeBody "what is 2+1"  -- JSON payload with the text question
    
    -- Set request method to POST
    let request = setRequestHeader "Content-Type" ["application/json"]
                  $ setRequestMethod "POST"
                  $ setRequestBodyLBS (L8.pack requestBody) initialRequest


    response <- liftIO $ httpLBS request

    -- Print response
    liftIO $ putStrLn "Response Body:"
    liftIO $ L8.putStrLn $ getResponseBody response
    S.text $ decodeUtf8 $ getResponseBody response